# LinguaFlow MVP

Telegram Mini App for Ukrainian-speaking English learners.

## Included
- React + TypeScript + Vite frontend (responsive learning dashboard and lesson flow)
- FastAPI backend scaffold
- PostgreSQL schema for users, CEFR courses, units, lessons, exercises, vocabulary, progress, streaks and subscriptions
- Telegram WebApp `initData` validation helper
- Seed curriculum outline for A1–C1

## Run locally

### Backend
```bash
cd backend
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env
uvicorn app.main:app --reload
```

### Frontend
```bash
cd frontend
npm install
cp .env.example .env
npm run dev
```

The frontend currently includes demo data and can be previewed without Telegram. For Telegram authentication, configure `VITE_API_URL`, `BOT_TOKEN`, HTTPS hosting and a Mini App URL in BotFather.

## Important launch notes
- Never expose the Telegram bot token in frontend code.
- Validate Telegram `initData` on the backend in production.
- Configure HTTPS before connecting the Mini App to Telegram.
- Payments are not enabled in this scaffold. Digital goods sold inside Telegram must follow Telegram Stars requirements. Add and test payment handling before accepting money.
- The included curriculum is a structured MVP outline, not a complete CEFR-certified course. Have lesson content reviewed before marketing it as a complete course.

## Telegram Stars Premium (payment foundation)

The paywall offers two one-time plans: `premium_week` (49 XTR / 7 days) and
`premium_month` (149 XTR / 30 days). They do not auto-renew. The backend creates
invoice links with Telegram's `createInvoiceLink`, validates Telegram Mini App
`initData`, answers `pre_checkout_query`, and activates access only after a
matching `successful_payment` update. Apply the full `database/schema.sql`
including the `payment_intents` table before testing payments.

Set `BOT_TOKEN`, `DATABASE_URL`, and a long random `WEBHOOK_SECRET` in the backend
environment. Configure the Telegram bot webhook to
`https://YOUR_API_HOST/api/telegram/webhook` with the same
`secret_token=WEBHOOK_SECRET`. The frontend needs `VITE_API_URL` pointing to the
backend. Never put the bot token or webhook secret in frontend variables.

Before accepting real payments, test the complete flow with a private test bot,
verify webhook delivery and duplicate-update handling, add a user-facing support
path (`/paysupport`), and implement refund handling/support procedures. Premium
access is checked through `GET /api/subscription`; lesson APIs must enforce that
status server-side before exposing paid content.
