import { useState } from 'react'
import { BookOpen, Brain, ChartNoAxesColumn, Flame, Headphones, Home, LockKeyhole, Menu, Mic, Sparkles, Trophy, UserRound, Volume2, Check, ChevronRight, X } from 'lucide-react'

const levels = [
  {code:'A1',name:'Beginner',desc:'Перші кроки англійською',progress:65,locked:false},
  {code:'A2',name:'Elementary',desc:'Спілкування у щоденних ситуаціях',progress:0,locked:false},
  {code:'B1',name:'Intermediate',desc:'Самостійне спілкування',progress:0,locked:true},
  {code:'B2',name:'Upper-Intermediate',desc:'Впевнена англійська',progress:0,locked:true},
  {code:'C1',name:'Advanced',desc:'Вільне володіння мовою',progress:0,locked:true},
]
const words = [{en:'Good morning',uk:'Доброго ранку',say:'/ɡʊd ˈmɔːnɪŋ/'},{en:'Nice to meet you',uk:'Приємно познайомитися',say:'/naɪs tə miːt juː/'},{en:'Where are you from?',uk:'Звідки ти?',say:'/weər ɑː juː frɒm/'}]

export default function App(){
 const [tab,setTab]=useState('home')
 const [lesson,setLesson]=useState(false)
 const [step,setStep]=useState(0)
 const [answer,setAnswer]=useState('')
 const [checked,setChecked]=useState(false)
 const [done,setDone]=useState(false)
 const [paymentLoading,setPaymentLoading]=useState('')
 const [paymentMessage,setPaymentMessage]=useState('')
 const current=words[step%words.length]
 const tg=(window as any).Telegram?.WebApp
 if(tg){tg.ready();tg.expand()}
 const start=()=>{setLesson(true);setStep(0);setAnswer('');setChecked(false);setDone(false)}
 const next=()=>{if(step>=4){setDone(true)}else{setStep(step+1);setAnswer('');setChecked(false)}}
 const buyPremium=async(planCode:string)=>{
  if(!tg?.initData){setPaymentMessage('Відкрий LinguaFlow через Telegram, щоб оплатити Stars.');return}
  setPaymentLoading(planCode);setPaymentMessage('')
  try{
   const api=(import.meta as any).env?.VITE_API_URL||''
   const response=await fetch(`${api}/api/payments/create-invoice`,{method:'POST',headers:{'Content-Type':'application/json','X-Telegram-Init-Data':tg.initData},body:JSON.stringify({plan_code:planCode})})
   const data=await response.json()
   if(!response.ok)throw new Error(data.detail||'Не вдалося створити рахунок')
   if(tg.openInvoice){tg.openInvoice(data.invoice_url,(status:string)=>{if(status==='paid')setPaymentMessage('Оплату прийнято. Telegram підтвердить її серверу, після чого Premium активується.');else if(status==='cancelled')setPaymentMessage('Оплату скасовано.');else if(status==='failed')setPaymentMessage('Платіж не пройшов. Спробуй ще раз.')})}
   else window.open(data.invoice_url,'_blank')
  }catch(error){setPaymentMessage(error instanceof Error?error.message:'Помилка оплати')}finally{setPaymentLoading('')}
 }
 return <div className="app">
  <header><div className="brand"><div className="logo">L</div><div><b>LinguaFlow</b><small>Твій шлях до англійської</small></div></div><button className="avatar" onClick={()=>setTab('profile')}>V</button></header>
  {lesson ? <main className="lesson">
   <button className="back" onClick={()=>setLesson(false)}><X size={17}/> Закрити урок</button>
   <div className="progressline"><span style={{width:`${Math.min(100,(step+1)*20)}%`}}/></div>
   {done ? <section className="card center"><div className="bigicon">🏆</div><h1>Урок завершено!</h1><p>Чудова робота. Ти заробив 50 XP.</p><button className="primary" onClick={()=>setLesson(false)}>До головної</button></section> :
   <><span className="eyebrow">A1 · УРОК 01 · СЛОВНИК</span><h1>Знайомство</h1><p className="muted">Вивчи слова та фрази для першої розмови.</p>
   <section className="wordcard"><span className="eyebrow">АНГЛІЙСЬКА ФРАЗА</span><h2>{current.en}</h2><p>{current.say}</p><button className="sound" onClick={()=>{}}><Volume2 size={18}/> Прослухати</button><div className="translation">{current.uk}</div></section>
   <section className="card"><b>Що означає ця фраза?</b><div className="answers">{[current.uk,'На добраніч','До побачення'].map(a=><button className={`answer ${answer===a?'selected':''} ${checked&&a===current.uk?'correct':''}`} onClick={()=>{setAnswer(a);setChecked(false)}}>{a}</button>)}</div>{checked&&<p className={answer===current.uk?'success':'error'}>{answer===current.uk?'Правильно! Молодець.':'Спробуй ще раз. Правильна відповідь: '+current.uk}</p>}<button className="primary full" disabled={!answer} onClick={()=>checked&&answer===current.uk?next():setChecked(true)}>{checked&&answer===current.uk?'Наступне':'Перевірити'}</button></section></>}
  </main> : <main>
   <section className="welcome"><div><span className="eyebrow">ВІТАЄМО В LINGUAFLOW</span><h1>Привіт! <span>👋</span></h1><p>Готовий зробити ще один крок до англійської?</p></div><div className="streak"><Flame size={18} fill="#ff9b52"/> 7</div></section>
   <section className="hero"><div className="hero-top"><span>ТВІЙ ПРОГРЕС</span><span className="levelpill">A1 · Beginner</span></div><div className="hero-score"><strong>65%</strong><span>до завершення рівня</span></div><div className="bar"><span/></div><div className="hero-foot"><span>8 з 12 уроків</span><span>Ще трохи! 🚀</span></div></section>
   <div className="stats"><div className="stat"><BookOpen/><b>245</b><small>Вивчених слів</small></div><div className="stat"><Sparkles/><b>1 250</b><small>Твої XP</small></div><div className="stat"><Flame/><b>7 днів</b><small>Серія навчання</small></div></div>
   <section className="sectionhead"><div><span className="eyebrow">ПРОДОВЖУЙ НАВЧАННЯ</span><h2>Урок дня</h2></div><span className="tag">10 хв</span></section>
   <section className="daily"><div className="dailyicon"><BookOpen size={25}/></div><div className="dailytext"><b>Everyday English</b><p>Знайомство · 10 слів · 5 завдань</p><span>+50 XP за урок</span></div><button className="round" onClick={start}><ChevronRight/></button></section>
   <section className="sectionhead"><div><span className="eyebrow">ТВОЯ ПРОГРАМА</span><h2>Рівні англійської</h2></div><button className="textbtn" onClick={()=>setTab('courses')}>Усі</button></section>
   <div className="levels">{levels.map((l,i)=><button className={`level ${l.locked?'locked':''}`} onClick={()=>!l.locked&&setTab('courses')}><div className="levelbadge">{l.locked?<LockKeyhole size={17}/>:l.code}</div><div className="levelinfo"><b>{l.code} · {l.name}</b><small>{l.desc}</small>{l.progress>0&&<div className="mini-bar"><span style={{width:l.progress+'%'}}/></div>}</div><ChevronRight size={18}/></button>)}</div>
   <section className="premium"><div><span className="eyebrow">LINGUAFLOW PREMIUM</span><h2>Більше англійської. Більше можливостей.</h2><p>Відкрий усі уроки та персональне повторення слів.</p><button onClick={()=>setTab('premium')}>Дізнатися більше <ChevronRight size={16}/></button></div><div className="premiumstar">✦</div></section>
  </main>}
  <nav>{[{id:'home',icon:Home,label:'Головна'},{id:'courses',icon:BookOpen,label:'Навчання'},{id:'vocab',icon:Brain,label:'Словник'},{id:'progress',icon:ChartNoAxesColumn,label:'Прогрес'},{id:'profile',icon:UserRound,label:'Профіль'}].map(n=><button className={tab===n.id?'active':''} onClick={()=>{setTab(n.id);setLesson(false)}}><n.icon size={20}/><small>{n.label}</small></button>)}</nav>
  {tab==='premium'&&!lesson&&<div className="paywall-overlay"><section className="paywall"><button className="paywall-close" onClick={()=>setTab('home')}><X size={18}/></button><span className="eyebrow">LINGUAFLOW PREMIUM</span><div className="paywall-star">✦</div><h1>Навчайся без обмежень</h1><p className="paywall-intro">Відкрий усі доступні уроки, повний словник і повторення слів.</p><ul><li>✓ Доступ до всіх опублікованих уроків</li><li>✓ Повторення слів та відстеження прогресу</li><li>✓ Без реклами та обмежень Free</li></ul><div className="plans"><button className="plan" onClick={()=>buyPremium('premium_week')} disabled={!!paymentLoading}><span><b>7 днів</b><small>Спробувати Premium</small></span><strong>49 ⭐</strong>{paymentLoading==='premium_week'&&<small>Створюємо рахунок…</small>}</button><button className="plan featured" onClick={()=>buyPremium('premium_month')} disabled={!!paymentLoading}><span><b>30 днів</b><small>Найвигідніший варіант</small></span><strong>149 ⭐</strong>{paymentLoading==='premium_month'&&<small>Створюємо рахунок…</small>}</button></div>{paymentMessage&&<p className="payment-message">{paymentMessage}</p>}<small className="paywall-note">Оплата разова. Підписка автоматично не продовжується. Платіж обробляється через Telegram Stars.</small></section></div>}
  {tab!=='home'&&tab!=='premium'&&!lesson&&<div className="toast"><b>{tab==='courses'?'Навчальна програма':tab==='vocab'?'Мій словник':tab==='progress'?'Мій прогрес':'Профіль'}</b><p>Розділ підключається на наступному етапі MVP.</p><button onClick={()=>setTab('home')}>На головну</button></div>}
 </div>
}
