INSERT INTO courses (cefr_level, title, description, sort_order) VALUES
('A1','Beginner','Перші кроки англійською',1),
('A2','Elementary','Спілкування у щоденних ситуаціях',2),
('B1','Intermediate','Самостійне спілкування',3),
('B2','Upper-Intermediate','Впевнене спілкування та аргументація',4),
('C1','Advanced','Просунута англійська та мовні нюанси',5)
ON CONFLICT (cefr_level) DO NOTHING;
