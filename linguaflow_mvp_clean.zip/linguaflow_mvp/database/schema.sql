CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TABLE users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  telegram_id BIGINT UNIQUE NOT NULL,
  username TEXT,
  first_name TEXT,
  interface_language TEXT NOT NULL DEFAULT 'uk',
  current_cefr_level TEXT CHECK (current_cefr_level IN ('A1','A2','B1','B2','C1')),
  xp INTEGER NOT NULL DEFAULT 0 CHECK (xp >= 0),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  last_active_at TIMESTAMPTZ
);

CREATE TABLE courses (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  cefr_level TEXT UNIQUE NOT NULL CHECK (cefr_level IN ('A1','A2','B1','B2','C1')),
  title TEXT NOT NULL,
  description TEXT,
  sort_order SMALLINT NOT NULL
);

CREATE TABLE units (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  course_id UUID NOT NULL REFERENCES courses(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  description TEXT,
  sort_order SMALLINT NOT NULL,
  UNIQUE(course_id, sort_order)
);

CREATE TABLE lessons (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  unit_id UUID NOT NULL REFERENCES units(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  estimated_minutes SMALLINT NOT NULL DEFAULT 10,
  sort_order SMALLINT NOT NULL,
  is_published BOOLEAN NOT NULL DEFAULT false,
  UNIQUE(unit_id, sort_order)
);

CREATE TABLE exercises (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  lesson_id UUID NOT NULL REFERENCES lessons(id) ON DELETE CASCADE,
  exercise_type TEXT NOT NULL CHECK (exercise_type IN ('multiple_choice','translation','word_order','listening','fill_blank')),
  prompt TEXT NOT NULL,
  options JSONB,
  correct_answer JSONB NOT NULL,
  explanation_uk TEXT,
  sort_order SMALLINT NOT NULL
);

CREATE TABLE vocabulary (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  lesson_id UUID REFERENCES lessons(id) ON DELETE SET NULL,
  word TEXT NOT NULL,
  translation_uk TEXT NOT NULL,
  transcription TEXT,
  example_en TEXT,
  example_uk TEXT,
  audio_url TEXT,
  cefr_level TEXT NOT NULL CHECK (cefr_level IN ('A1','A2','B1','B2','C1')),
  UNIQUE(word, cefr_level)
);

CREATE TABLE user_lesson_progress (
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  lesson_id UUID NOT NULL REFERENCES lessons(id) ON DELETE CASCADE,
  status TEXT NOT NULL DEFAULT 'not_started' CHECK (status IN ('not_started','in_progress','completed')),
  score NUMERIC(5,2),
  attempts INTEGER NOT NULL DEFAULT 0,
  completed_at TIMESTAMPTZ,
  PRIMARY KEY(user_id, lesson_id)
);

CREATE TABLE user_vocabulary (
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  vocabulary_id UUID NOT NULL REFERENCES vocabulary(id) ON DELETE CASCADE,
  familiarity SMALLINT NOT NULL DEFAULT 0 CHECK (familiarity BETWEEN 0 AND 5),
  repetitions INTEGER NOT NULL DEFAULT 0,
  interval_days INTEGER NOT NULL DEFAULT 0,
  ease_factor NUMERIC(3,2) NOT NULL DEFAULT 2.50,
  next_review_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  last_reviewed_at TIMESTAMPTZ,
  PRIMARY KEY(user_id, vocabulary_id)
);

CREATE TABLE daily_activity (
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  activity_date DATE NOT NULL,
  minutes_studied INTEGER NOT NULL DEFAULT 0,
  xp_earned INTEGER NOT NULL DEFAULT 0,
  lessons_completed INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY(user_id, activity_date)
);

CREATE TABLE subscriptions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  plan_code TEXT NOT NULL CHECK (plan_code IN ('free','premium','pro_ai')),
  provider TEXT,
  provider_subscription_id TEXT,
  status TEXT NOT NULL DEFAULT 'inactive' CHECK (status IN ('trialing','active','past_due','cancelled','expired','inactive')),
  started_at TIMESTAMPTZ,
  expires_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_lessons_unit ON lessons(unit_id, sort_order);
CREATE INDEX idx_exercises_lesson ON exercises(lesson_id, sort_order);
CREATE INDEX idx_vocab_review ON user_vocabulary(user_id, next_review_at);
CREATE INDEX idx_activity_date ON daily_activity(user_id, activity_date DESC);
CREATE INDEX idx_subscriptions_user_status ON subscriptions(user_id, status);

-- Telegram Stars one-time payment intents. Prices are stored server-side and
-- checked again against Telegram's successful_payment update.
CREATE TABLE payment_intents (
  id UUID PRIMARY KEY,
  telegram_id BIGINT NOT NULL,
  plan_code TEXT NOT NULL CHECK (plan_code IN ('premium_week','premium_month')),
  expected_amount INTEGER NOT NULL CHECK (expected_amount > 0),
  currency TEXT NOT NULL DEFAULT 'XTR' CHECK (currency = 'XTR'),
  payload TEXT GENERATED ALWAYS AS ('lf:' || id::text) STORED UNIQUE,
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','paid','failed','refunded')),
  telegram_payment_charge_id TEXT UNIQUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  paid_at TIMESTAMPTZ
);

CREATE INDEX idx_payment_intents_telegram_status ON payment_intents(telegram_id, status);
CREATE UNIQUE INDEX idx_subscriptions_telegram_charge ON subscriptions(provider_subscription_id)
  WHERE provider = 'telegram_stars' AND provider_subscription_id IS NOT NULL;
