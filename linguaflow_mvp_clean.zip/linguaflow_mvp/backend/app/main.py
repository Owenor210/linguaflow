import json
import uuid
from contextlib import asynccontextmanager
from datetime import datetime, timedelta, timezone

import asyncpg
import httpx
from fastapi import FastAPI, Header, HTTPException, Request
from pydantic import BaseModel

from .config import settings
from .telegram_auth import validate_telegram_init_data

PLANS = {
    "premium_week": {"title": "LinguaFlow Premium — 7 днів", "stars": 49, "days": 7},
    "premium_month": {"title": "LinguaFlow Premium — 30 днів", "stars": 149, "days": 30},
}

pool: asyncpg.Pool | None = None

@asynccontextmanager
async def lifespan(app: FastAPI):
    global pool
    if settings.database_url:
        pool = await asyncpg.create_pool(settings.database_url, min_size=1, max_size=5)
    yield
    if pool:
        await pool.close()

app = FastAPI(title="LinguaFlow API", version="0.2.0", lifespan=lifespan)

@app.get("/health")
async def health():
    return {"status": "ok", "service": "LinguaFlow API"}

@app.get("/api/courses")
def courses():
    return [
        {"code": "A1", "title": "Beginner", "description": "Перші слова та прості речення", "units": 8},
        {"code": "A2", "title": "Elementary", "description": "Побутове спілкування", "units": 8},
        {"code": "B1", "title": "Intermediate", "description": "Самостійне спілкування", "units": 8},
        {"code": "B2", "title": "Upper-Intermediate", "description": "Вільніше та точніше спілкування", "units": 8},
        {"code": "C1", "title": "Advanced", "description": "Складні тексти та нюанси мови", "units": 8},
    ]

async def authenticated_user(init_data: str):
    if not settings.bot_token:
        raise HTTPException(status_code=503, detail="Telegram bot token is not configured")
    try:
        return validate_telegram_init_data(init_data, settings.bot_token)
    except Exception:
        raise HTTPException(status_code=401, detail="Invalid or expired Telegram initData")

async def ensure_user(user: dict):
    if not pool:
        raise HTTPException(status_code=503, detail="Database is not configured")
    await pool.execute(
        """INSERT INTO users (telegram_id, username, first_name, last_active_at)
           VALUES ($1, $2, $3, now())
           ON CONFLICT (telegram_id) DO UPDATE SET username=EXCLUDED.username,
           first_name=EXCLUDED.first_name, last_active_at=now()""",
        int(user["id"]), user.get("username"), user.get("first_name", "")
    )

@app.post("/api/payments/create-invoice")
async def create_invoice(request: Request, x_telegram_init_data: str = Header(default="", alias="X-Telegram-Init-Data")):
    user = await authenticated_user(x_telegram_init_data)
    body = await request.json()
    plan_code = body.get("plan_code")
    if plan_code not in PLANS:
        raise HTTPException(status_code=400, detail="Unknown subscription plan")
    await ensure_user(user)
    plan = PLANS[plan_code]
    intent_id = str(uuid.uuid4())
    payload = f"lf:{intent_id}"
    await pool.execute(
        """INSERT INTO payment_intents (id, telegram_id, plan_code, expected_amount, currency, status)
           VALUES ($1, $2, $3, $4, 'XTR', 'pending')""",
        uuid.UUID(intent_id), int(user["id"]), plan_code, plan["stars"]
    )
    invoice = {
        "title": plan["title"],
        "description": f"Доступ до LinguaFlow Premium на {plan['days']} днів",
        "payload": payload,
        "provider_token": "",
        "currency": "XTR",
        "prices": [{"label": plan["title"], "amount": plan["stars"]}],
    }
    async with httpx.AsyncClient(timeout=15) as client:
        response = await client.post(f"https://api.telegram.org/bot{settings.bot_token}/createInvoiceLink", json=invoice)
    data = response.json()
    if response.status_code != 200 or not data.get("ok"):
        await pool.execute("UPDATE payment_intents SET status='failed' WHERE id=$1", uuid.UUID(intent_id))
        raise HTTPException(status_code=502, detail="Telegram не зміг створити рахунок")
    return {"invoice_url": data["result"], "plan_code": plan_code, "stars": plan["stars"], "days": plan["days"]}

@app.post("/api/telegram/webhook")
async def telegram_webhook(
    update: dict,
    x_telegram_bot_api_secret_token: str = Header(default="", alias="X-Telegram-Bot-Api-Secret-Token")
):
    if not settings.webhook_secret or x_telegram_bot_api_secret_token != settings.webhook_secret:
        raise HTTPException(status_code=403, detail="Invalid webhook secret")
    if not pool:
        raise HTTPException(status_code=503, detail="Database is not configured")

    async with httpx.AsyncClient(timeout=10) as client:
        if "pre_checkout_query" in update:
            query = update["pre_checkout_query"]
            intent = await pool.fetchrow(
                "SELECT * FROM payment_intents WHERE payload=$1 AND telegram_id=$2 AND status='pending'",
                query.get("invoice_payload"), int(query["from"]["id"])
            )
            valid = bool(intent and query.get("currency") == "XTR" and query.get("total_amount") == intent["expected_amount"])
            await client.post(f"https://api.telegram.org/bot{settings.bot_token}/answerPreCheckoutQuery", json={
                "pre_checkout_query_id": query["id"],
                "ok": valid,
                **({} if valid else {"error_message": "Рахунок недійсний. Спробуйте створити оплату ще раз."})
            })
            return {"ok": True}

        message = update.get("message", {})
        payment = message.get("successful_payment")
        if payment:
            tg_id = int(message["from"]["id"])
            async with pool.acquire() as conn:
                async with conn.transaction():
                    intent = await conn.fetchrow(
                        "SELECT * FROM payment_intents WHERE payload=$1 AND telegram_id=$2 AND status='pending' FOR UPDATE",
                        payment.get("invoice_payload"), tg_id
                    )
                    if not intent or payment.get("currency") != "XTR" or payment.get("total_amount") != intent["expected_amount"]:
                        return {"ok": True, "ignored": "unmatched_payment"}
                    plan = PLANS[intent["plan_code"]]
                    now = datetime.now(timezone.utc)
                    existing = await conn.fetchrow(
                        "SELECT expires_at FROM subscriptions WHERE user_id=(SELECT id FROM users WHERE telegram_id=$1) AND status='active' AND expires_at>now() ORDER BY expires_at DESC LIMIT 1",
                        tg_id
                    )
                    start = max(now, existing["expires_at"]) if existing and existing["expires_at"] else now
                    expires = start + timedelta(days=plan["days"])
                    await conn.execute(
                        """INSERT INTO subscriptions (user_id, plan_code, provider, provider_subscription_id, status, started_at, expires_at)
                           VALUES ((SELECT id FROM users WHERE telegram_id=$1), 'premium', 'telegram_stars', $2, 'active', $3, $4)""",
                        tg_id, payment["telegram_payment_charge_id"], start, expires
                    )
                    await conn.execute(
                        "UPDATE payment_intents SET status='paid', telegram_payment_charge_id=$2, paid_at=now() WHERE id=$1",
                        intent["id"], payment["telegram_payment_charge_id"]
                    )
        return {"ok": True}

@app.get("/api/subscription")
async def subscription(x_telegram_init_data: str = Header(default="", alias="X-Telegram-Init-Data")):
    user = await authenticated_user(x_telegram_init_data)
    if not pool:
        raise HTTPException(status_code=503, detail="Database is not configured")
    row = await pool.fetchrow(
        """SELECT s.plan_code, s.status, s.expires_at FROM subscriptions s
           JOIN users u ON u.id=s.user_id WHERE u.telegram_id=$1 AND s.status='active' AND s.expires_at>now()
           ORDER BY s.expires_at DESC LIMIT 1""", int(user["id"])
    )
    return {"active": bool(row), "plan_code": row["plan_code"] if row else "free", "expires_at": row["expires_at"].isoformat() if row else None}

class Answer(BaseModel):
    exercise_id: str
    answer: str

@app.post("/api/lesson/check")
def check_answer(payload: Answer):
    return {"exercise_id": payload.exercise_id, "message": "Підключіть контент уроку та перевірку з бази даних."}
