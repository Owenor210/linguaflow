from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    bot_token: str = ""
    database_url: str = "postgresql://postgres:postgres@localhost:5432/linguaflow"
    app_env: str = "development"
    webhook_secret: str = ""
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

settings = Settings()
