import hashlib
import hmac
import json
from urllib.parse import parse_qsl
from datetime import datetime, timezone

def validate_telegram_init_data(init_data: str, bot_token: str, max_age_seconds: int = 86400) -> dict:
    \"\"\"Validate Telegram Mini App initData. Never trust user data from the browser alone.\"\"\"
    if not bot_token:
        raise ValueError("BOT_TOKEN is not configured")
    parsed = dict(parse_qsl(init_data, keep_blank_values=True))
    received_hash = parsed.pop("hash", None)
    if not received_hash:
        raise ValueError("Missing Telegram hash")

    data_check_string = "\\n".join(f"{k}={v}" for k, v in sorted(parsed.items()))
    secret_key = hmac.new(b"WebAppData", bot_token.encode(), hashlib.sha256).digest()
    calculated = hmac.new(secret_key, data_check_string.encode(), hashlib.sha256).hexdigest()

    if not hmac.compare_digest(calculated, received_hash):
        raise ValueError("Invalid Telegram initData signature")

    auth_date = int(parsed.get("auth_date", "0"))
    now = int(datetime.now(timezone.utc).timestamp())
    if auth_date <= 0 or now - auth_date > max_age_seconds or auth_date > now + 60:
        raise ValueError("Expired Telegram initData")

    user = json.loads(parsed.get("user", "{}"))
    if not user.get("id"):
        raise ValueError("Telegram user ID missing")
    return user
